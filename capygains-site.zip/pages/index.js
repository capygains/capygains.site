export default function CapyGains() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 to-yellow-50 p-6 text-center">
      <div className="flex justify-center mb-6">
        <img
          src="/twitpro.png"
          alt="Capy Gains Logo"
          width={120}
          height={120}
          className="rounded-full shadow-md"
        />
      </div>

      <h1 className="text-5xl font-extrabold text-green-800 mb-4">
        Capy Gains
      </h1>
      <p className="text-lg text-gray-700 mb-4">
        The chillest capybara in crypto is here to make you laugh... and moon 🚀
      </p>
      <p className="text-md text-gray-600 italic mb-8">
        Ticker will be announced at launch with CA.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        <div className="rounded-2xl shadow-md hover:shadow-xl transition p-6 bg-white">
          <div className="text-green-500 mb-3 w-8 h-8 mx-auto">📈</div>
          <h2 className="text-xl font-bold mb-2">Capyonomics</h2>
          <p className="text-gray-600">
            Fixed supply of 21 million. No presale. 100% fair launch. Proof-of-chill.
          </p>
        </div>

        <div className="rounded-2xl shadow-md hover:shadow-xl transition p-6 bg-white">
          <div className="text-yellow-500 mb-3 w-8 h-8 mx-auto">🚀</div>
          <h2 className="text-xl font-bold mb-2">Why Capy Gains?</h2>
          <p className="text-gray-600">
            Capybara vibes + meme culture + hard caps. Built for hodlers who just wanna vibe.
          </p>
        </div>
      </div>

      <div className="mt-10 flex flex-col items-center gap-4">
        <button className="text-white bg-green-600 hover:bg-green-700 px-6 py-3 rounded-2xl text-lg">
          Launch Sniper Tool
        </button>
        <a
          href="https://twitter.com/capygains"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center text-blue-600 hover:text-blue-800"
        >
          <span className="mr-2">🐦</span>
          Follow us on Twitter
        </a>
      </div>
    </div>
  );
}
